var _http = 'http://xianheng.mumarenkj.com';
var _token = store.get('token');
console.log(_token);